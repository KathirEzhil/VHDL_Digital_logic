/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/ALU_DLS_mini_project/DLS_MP_ALU_16bit.vhd";
extern char *IEEE_P_1242562249;
extern char *IEEE_P_2592010699;

char *ieee_p_1242562249_sub_10420449594411817395_1035706684(char *, char *, int , int );
unsigned char ieee_p_1242562249_sub_1434214030532753770_1035706684(char *, char *, char *, char *, char *);
unsigned char ieee_p_1242562249_sub_1434214030532825644_1035706684(char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_1701011461141717515_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_1701011461141789389_1035706684(char *, char *, char *, char *, char *, char *);
int ieee_p_1242562249_sub_17802405650254020620_1035706684(char *, char *, char *);
unsigned char ieee_p_1242562249_sub_3307759752501539734_1035706684(char *, char *, char *, int );
char *ieee_p_2592010699_sub_16439767405979520975_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_16439989832805790689_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_16439989833707593767_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_207919886985903570_503743352(char *, char *, char *, char *);


static void work_a_3431638527_3212880686_p_0(char *t0)
{
    char t68[16];
    char t80[16];
    char t83[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    int t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    int t16;
    char *t17;
    int t19;
    char *t20;
    int t22;
    char *t23;
    int t25;
    char *t26;
    int t28;
    char *t29;
    int t31;
    char *t32;
    int t34;
    char *t35;
    int t37;
    char *t38;
    int t40;
    char *t41;
    int t43;
    char *t44;
    int t46;
    char *t47;
    int t49;
    char *t50;
    int t52;
    char *t53;
    int t55;
    char *t56;
    int t58;
    char *t59;
    int t61;
    char *t62;
    int t64;
    char *t65;
    int t67;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    char *t75;
    char *t76;
    unsigned int t77;
    unsigned int t78;
    unsigned char t79;
    unsigned int t81;
    unsigned int t82;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;

LAB0:    xsi_set_current_line(59, ng0);
    t1 = xsi_get_transient_memory(16U);
    memset(t1, 0, 16U);
    t2 = t1;
    memset(t2, (unsigned char)2, 16U);
    t3 = (t0 + 2808U);
    t4 = *((char **)t3);
    t3 = (t4 + 0);
    memcpy(t3, t1, 16U);
    xsi_set_current_line(60, ng0);
    t1 = (t0 + 4184);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(61, ng0);
    t1 = (t0 + 4248);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(64, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6984);
    t6 = xsi_mem_cmp(t1, t2, 5U);
    if (t6 == 1)
        goto LAB3;

LAB26:    t4 = (t0 + 6989);
    t7 = xsi_mem_cmp(t4, t2, 5U);
    if (t7 == 1)
        goto LAB4;

LAB27:    t8 = (t0 + 6994);
    t10 = xsi_mem_cmp(t8, t2, 5U);
    if (t10 == 1)
        goto LAB5;

LAB28:    t11 = (t0 + 6999);
    t13 = xsi_mem_cmp(t11, t2, 5U);
    if (t13 == 1)
        goto LAB6;

LAB29:    t14 = (t0 + 7004);
    t16 = xsi_mem_cmp(t14, t2, 5U);
    if (t16 == 1)
        goto LAB7;

LAB30:    t17 = (t0 + 7009);
    t19 = xsi_mem_cmp(t17, t2, 5U);
    if (t19 == 1)
        goto LAB8;

LAB31:    t20 = (t0 + 7014);
    t22 = xsi_mem_cmp(t20, t2, 5U);
    if (t22 == 1)
        goto LAB9;

LAB32:    t23 = (t0 + 7019);
    t25 = xsi_mem_cmp(t23, t2, 5U);
    if (t25 == 1)
        goto LAB10;

LAB33:    t26 = (t0 + 7024);
    t28 = xsi_mem_cmp(t26, t2, 5U);
    if (t28 == 1)
        goto LAB11;

LAB34:    t29 = (t0 + 7029);
    t31 = xsi_mem_cmp(t29, t2, 5U);
    if (t31 == 1)
        goto LAB12;

LAB35:    t32 = (t0 + 7034);
    t34 = xsi_mem_cmp(t32, t2, 5U);
    if (t34 == 1)
        goto LAB13;

LAB36:    t35 = (t0 + 7039);
    t37 = xsi_mem_cmp(t35, t2, 5U);
    if (t37 == 1)
        goto LAB14;

LAB37:    t38 = (t0 + 7044);
    t40 = xsi_mem_cmp(t38, t2, 5U);
    if (t40 == 1)
        goto LAB15;

LAB38:    t41 = (t0 + 7049);
    t43 = xsi_mem_cmp(t41, t2, 5U);
    if (t43 == 1)
        goto LAB16;

LAB39:    t44 = (t0 + 7054);
    t46 = xsi_mem_cmp(t44, t2, 5U);
    if (t46 == 1)
        goto LAB17;

LAB40:    t47 = (t0 + 7059);
    t49 = xsi_mem_cmp(t47, t2, 5U);
    if (t49 == 1)
        goto LAB18;

LAB41:    t50 = (t0 + 7064);
    t52 = xsi_mem_cmp(t50, t2, 5U);
    if (t52 == 1)
        goto LAB19;

LAB42:    t53 = (t0 + 7069);
    t55 = xsi_mem_cmp(t53, t2, 5U);
    if (t55 == 1)
        goto LAB20;

LAB43:    t56 = (t0 + 7074);
    t58 = xsi_mem_cmp(t56, t2, 5U);
    if (t58 == 1)
        goto LAB21;

LAB44:    t59 = (t0 + 7079);
    t61 = xsi_mem_cmp(t59, t2, 5U);
    if (t61 == 1)
        goto LAB22;

LAB45:    t62 = (t0 + 7084);
    t64 = xsi_mem_cmp(t62, t2, 5U);
    if (t64 == 1)
        goto LAB23;

LAB46:    t65 = (t0 + 7089);
    t67 = xsi_mem_cmp(t65, t2, 5U);
    if (t67 == 1)
        goto LAB24;

LAB47:
LAB25:    xsi_set_current_line(162, ng0);
    t1 = xsi_get_transient_memory(16U);
    memset(t1, 0, 16U);
    t2 = t1;
    memset(t2, (unsigned char)2, 16U);
    t3 = (t0 + 2808U);
    t4 = *((char **)t3);
    t3 = (t4 + 0);
    memcpy(t3, t1, 16U);

LAB2:    xsi_set_current_line(166, ng0);
    t1 = (t0 + 2808U);
    t2 = *((char **)t1);
    t1 = (t0 + 4312);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    memcpy(t8, t2, 16U);
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(168, ng0);
    t1 = (t0 + 2808U);
    t2 = *((char **)t1);
    t1 = (t0 + 7128);
    t79 = 1;
    if (16U == 16U)
        goto LAB97;

LAB98:    t79 = 0;

LAB99:    if (t79 != 0)
        goto LAB94;

LAB96:    xsi_set_current_line(170, ng0);
    t1 = (t0 + 4376);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB95:    xsi_set_current_line(173, ng0);
    t1 = (t0 + 2808U);
    t2 = *((char **)t1);
    t6 = (15 - 15);
    t77 = (t6 * -1);
    t78 = (1U * t77);
    t81 = (0 + t78);
    t1 = (t2 + t81);
    t79 = *((unsigned char *)t1);
    t3 = (t0 + 4440);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t79;
    xsi_driver_first_trans_fast_port(t3);
    t1 = (t0 + 4104);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(69, ng0);
    t69 = (t0 + 1032U);
    t70 = *((char **)t69);
    t69 = (t0 + 6816U);
    t71 = (t0 + 1192U);
    t72 = *((char **)t71);
    t71 = (t0 + 6832U);
    t73 = ieee_p_1242562249_sub_1701011461141717515_1035706684(IEEE_P_1242562249, t68, t70, t69, t72, t71);
    t74 = (t0 + 2808U);
    t75 = *((char **)t74);
    t74 = (t75 + 0);
    t76 = (t68 + 12U);
    t77 = *((unsigned int *)t76);
    t78 = (1U * t77);
    memcpy(t74, t73, t78);
    xsi_set_current_line(70, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t5 = ieee_p_1242562249_sub_1701011461141717515_1035706684(IEEE_P_1242562249, t68, t2, t1, t4, t3);
    t79 = ieee_p_1242562249_sub_3307759752501539734_1035706684(IEEE_P_1242562249, t5, t68, 65535);
    if (t79 != 0)
        goto LAB49;

LAB51:    xsi_set_current_line(72, ng0);
    t1 = (t0 + 4184);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB50:    goto LAB2;

LAB4:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t5 = ieee_p_1242562249_sub_1701011461141789389_1035706684(IEEE_P_1242562249, t68, t2, t1, t4, t3);
    t8 = (t0 + 2808U);
    t9 = *((char **)t8);
    t8 = (t9 + 0);
    t11 = (t68 + 12U);
    t77 = *((unsigned int *)t11);
    t78 = (1U * t77);
    memcpy(t8, t5, t78);
    goto LAB2;

LAB5:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t6 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t2, t1);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t7 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t4, t3);
    t10 = (t6 * t7);
    t5 = (t0 + 2568U);
    t8 = *((char **)t5);
    t5 = (t8 + 0);
    *((int *)t5) = t10;
    xsi_set_current_line(80, ng0);
    t1 = (t0 + 2568U);
    t2 = *((char **)t1);
    t6 = *((int *)t2);
    t7 = xsi_vhdl_mod(t6, 65535);
    t1 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t68, t7, 16);
    t3 = (t0 + 2808U);
    t4 = *((char **)t3);
    t3 = (t4 + 0);
    t5 = (t68 + 12U);
    t77 = *((unsigned int *)t5);
    t77 = (t77 * 1U);
    memcpy(t3, t1, t77);
    goto LAB2;

LAB6:    xsi_set_current_line(83, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 7094);
    t79 = 1;
    if (16U == 16U)
        goto LAB55;

LAB56:    t79 = 0;

LAB57:    if (t79 != 0)
        goto LAB52;

LAB54:    xsi_set_current_line(87, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t6 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t2, t1);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t7 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t4, t3);
    t10 = (t6 / t7);
    t5 = (t0 + 2688U);
    t8 = *((char **)t5);
    t5 = (t8 + 0);
    *((int *)t5) = t10;
    xsi_set_current_line(88, ng0);
    t1 = (t0 + 2688U);
    t2 = *((char **)t1);
    t6 = *((int *)t2);
    t1 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t68, t6, 16);
    t3 = (t0 + 2808U);
    t4 = *((char **)t3);
    t3 = (t4 + 0);
    t5 = (t68 + 12U);
    t77 = *((unsigned int *)t5);
    t77 = (t77 * 1U);
    memcpy(t3, t1, t77);

LAB53:    goto LAB2;

LAB7:    xsi_set_current_line(93, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 7110);
    t79 = 1;
    if (16U == 16U)
        goto LAB64;

LAB65:    t79 = 0;

LAB66:    if (t79 != 0)
        goto LAB61;

LAB63:    xsi_set_current_line(97, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t6 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t2, t1);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t7 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t4, t3);
    t10 = xsi_vhdl_mod(t6, t7);
    t5 = (t0 + 2688U);
    t8 = *((char **)t5);
    t5 = (t8 + 0);
    *((int *)t5) = t10;
    xsi_set_current_line(98, ng0);
    t1 = (t0 + 2688U);
    t2 = *((char **)t1);
    t6 = *((int *)t2);
    t1 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t68, t6, 16);
    t3 = (t0 + 2808U);
    t4 = *((char **)t3);
    t3 = (t4 + 0);
    t5 = (t68 + 12U);
    t77 = *((unsigned int *)t5);
    t77 = (t77 * 1U);
    memcpy(t3, t1, t77);

LAB62:    goto LAB2;

LAB8:    xsi_set_current_line(103, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t5 = ieee_p_2592010699_sub_16439989832805790689_503743352(IEEE_P_2592010699, t68, t2, t1, t4, t3);
    t8 = (t0 + 2808U);
    t9 = *((char **)t8);
    t8 = (t9 + 0);
    t11 = (t68 + 12U);
    t77 = *((unsigned int *)t11);
    t78 = (1U * t77);
    memcpy(t8, t5, t78);
    goto LAB2;

LAB9:    xsi_set_current_line(105, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t5 = ieee_p_2592010699_sub_16439767405979520975_503743352(IEEE_P_2592010699, t68, t2, t1, t4, t3);
    t8 = (t0 + 2808U);
    t9 = *((char **)t8);
    t8 = (t9 + 0);
    t11 = (t68 + 12U);
    t77 = *((unsigned int *)t11);
    t78 = (1U * t77);
    memcpy(t8, t5, t78);
    goto LAB2;

LAB10:    xsi_set_current_line(107, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t5 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t68, t2, t1, t4, t3);
    t8 = (t0 + 2808U);
    t9 = *((char **)t8);
    t8 = (t9 + 0);
    t11 = (t68 + 12U);
    t77 = *((unsigned int *)t11);
    t78 = (1U * t77);
    memcpy(t8, t5, t78);
    goto LAB2;

LAB11:    xsi_set_current_line(109, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t5 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t80, t2, t1, t4, t3);
    t8 = ieee_p_2592010699_sub_207919886985903570_503743352(IEEE_P_2592010699, t68, t5, t80);
    t9 = (t0 + 2808U);
    t11 = *((char **)t9);
    t9 = (t11 + 0);
    t12 = (t68 + 12U);
    t77 = *((unsigned int *)t12);
    t78 = (1U * t77);
    memcpy(t9, t8, t78);
    goto LAB2;

LAB12:    xsi_set_current_line(111, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t5 = ieee_p_2592010699_sub_16439989832805790689_503743352(IEEE_P_2592010699, t80, t2, t1, t4, t3);
    t8 = ieee_p_2592010699_sub_207919886985903570_503743352(IEEE_P_2592010699, t68, t5, t80);
    t9 = (t0 + 2808U);
    t11 = *((char **)t9);
    t9 = (t11 + 0);
    t12 = (t68 + 12U);
    t77 = *((unsigned int *)t12);
    t78 = (1U * t77);
    memcpy(t9, t8, t78);
    goto LAB2;

LAB13:    xsi_set_current_line(113, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t5 = ieee_p_2592010699_sub_16439767405979520975_503743352(IEEE_P_2592010699, t80, t2, t1, t4, t3);
    t8 = ieee_p_2592010699_sub_207919886985903570_503743352(IEEE_P_2592010699, t68, t5, t80);
    t9 = (t0 + 2808U);
    t11 = *((char **)t9);
    t9 = (t11 + 0);
    t12 = (t68 + 12U);
    t77 = *((unsigned int *)t12);
    t78 = (1U * t77);
    memcpy(t9, t8, t78);
    goto LAB2;

LAB14:    xsi_set_current_line(115, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t3 = ieee_p_2592010699_sub_207919886985903570_503743352(IEEE_P_2592010699, t68, t2, t1);
    t4 = (t0 + 2808U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    t8 = (t68 + 12U);
    t77 = *((unsigned int *)t8);
    t78 = (1U * t77);
    memcpy(t4, t3, t78);
    goto LAB2;

LAB15:    xsi_set_current_line(117, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 6832U);
    t3 = ieee_p_2592010699_sub_207919886985903570_503743352(IEEE_P_2592010699, t68, t2, t1);
    t4 = (t0 + 2808U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    t8 = (t68 + 12U);
    t77 = *((unsigned int *)t8);
    t78 = (1U * t77);
    memcpy(t4, t3, t78);
    goto LAB2;

LAB16:    xsi_set_current_line(121, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t77 = (15 - 14);
    t78 = (t77 * 1U);
    t81 = (0 + t78);
    t1 = (t2 + t81);
    t3 = (t0 + 7126);
    t8 = ((IEEE_P_2592010699) + 4000);
    t9 = (t80 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 14;
    t11 = (t9 + 4U);
    *((int *)t11) = 0;
    t11 = (t9 + 8U);
    *((int *)t11) = -1;
    t6 = (0 - 14);
    t82 = (t6 * -1);
    t82 = (t82 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t82;
    t11 = (t83 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 0;
    t12 = (t11 + 4U);
    *((int *)t12) = 0;
    t12 = (t11 + 8U);
    *((int *)t12) = 1;
    t7 = (0 - 0);
    t82 = (t7 * 1);
    t82 = (t82 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t82;
    t5 = xsi_base_array_concat(t5, t68, t8, (char)97, t1, t80, (char)97, t3, t83, (char)101);
    t12 = (t0 + 2808U);
    t14 = *((char **)t12);
    t12 = (t14 + 0);
    t82 = (15U + 1U);
    memcpy(t12, t5, t82);
    goto LAB2;

LAB17:    xsi_set_current_line(123, ng0);
    t1 = (t0 + 7127);
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t77 = (15 - 15);
    t78 = (t77 * 1U);
    t81 = (0 + t78);
    t3 = (t4 + t81);
    t8 = ((IEEE_P_2592010699) + 4000);
    t9 = (t80 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 0;
    t11 = (t9 + 4U);
    *((int *)t11) = 0;
    t11 = (t9 + 8U);
    *((int *)t11) = 1;
    t6 = (0 - 0);
    t82 = (t6 * 1);
    t82 = (t82 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t82;
    t11 = (t83 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 15;
    t12 = (t11 + 4U);
    *((int *)t12) = 1;
    t12 = (t11 + 8U);
    *((int *)t12) = -1;
    t7 = (1 - 15);
    t82 = (t7 * -1);
    t82 = (t82 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t82;
    t5 = xsi_base_array_concat(t5, t68, t8, (char)97, t1, t80, (char)97, t3, t83, (char)101);
    t12 = (t0 + 2808U);
    t14 = *((char **)t12);
    t12 = (t14 + 0);
    t82 = (1U + 15U);
    memcpy(t12, t5, t82);
    goto LAB2;

LAB18:    xsi_set_current_line(125, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t6 = (15 - 15);
    t77 = (t6 * -1);
    t78 = (1U * t77);
    t81 = (0 + t78);
    t1 = (t2 + t81);
    t79 = *((unsigned char *)t1);
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t82 = (15 - 15);
    t84 = (t82 * 1U);
    t85 = (0 + t84);
    t3 = (t4 + t85);
    t8 = ((IEEE_P_2592010699) + 4000);
    t9 = (t80 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 15;
    t11 = (t9 + 4U);
    *((int *)t11) = 1;
    t11 = (t9 + 8U);
    *((int *)t11) = -1;
    t7 = (1 - 15);
    t86 = (t7 * -1);
    t86 = (t86 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t86;
    t5 = xsi_base_array_concat(t5, t68, t8, (char)99, t79, (char)97, t3, t80, (char)101);
    t11 = (t0 + 2808U);
    t12 = *((char **)t11);
    t11 = (t12 + 0);
    t86 = (1U + 15U);
    memcpy(t11, t5, t86);
    goto LAB2;

LAB19:    xsi_set_current_line(131, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t79 = 1;
    if (16U == 16U)
        goto LAB73;

LAB74:    t79 = 0;

LAB75:    if (t79 != 0)
        goto LAB70;

LAB72:    xsi_set_current_line(134, ng0);
    t1 = xsi_get_transient_memory(16U);
    memset(t1, 0, 16U);
    t2 = t1;
    memset(t2, (unsigned char)2, 16U);
    t3 = (t0 + 2808U);
    t4 = *((char **)t3);
    t3 = (t4 + 0);
    memcpy(t3, t1, 16U);

LAB71:    goto LAB2;

LAB20:    xsi_set_current_line(138, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t79 = 1;
    if (16U == 16U)
        goto LAB82;

LAB83:    t79 = 0;

LAB84:    if ((!(t79)) != 0)
        goto LAB79;

LAB81:    xsi_set_current_line(141, ng0);
    t1 = xsi_get_transient_memory(16U);
    memset(t1, 0, 16U);
    t2 = t1;
    memset(t2, (unsigned char)2, 16U);
    t3 = (t0 + 2808U);
    t4 = *((char **)t3);
    t3 = (t4 + 0);
    memcpy(t3, t1, 16U);

LAB80:    goto LAB2;

LAB21:    xsi_set_current_line(145, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t79 = ieee_p_1242562249_sub_1434214030532825644_1035706684(IEEE_P_1242562249, t2, t1, t4, t3);
    if (t79 != 0)
        goto LAB88;

LAB90:    xsi_set_current_line(148, ng0);
    t1 = xsi_get_transient_memory(16U);
    memset(t1, 0, 16U);
    t2 = t1;
    memset(t2, (unsigned char)2, 16U);
    t3 = (t0 + 2808U);
    t4 = *((char **)t3);
    t3 = (t4 + 0);
    memcpy(t3, t1, 16U);

LAB89:    goto LAB2;

LAB22:    xsi_set_current_line(152, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6816U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6832U);
    t79 = ieee_p_1242562249_sub_1434214030532753770_1035706684(IEEE_P_1242562249, t2, t1, t4, t3);
    if (t79 != 0)
        goto LAB91;

LAB93:    xsi_set_current_line(155, ng0);
    t1 = xsi_get_transient_memory(16U);
    memset(t1, 0, 16U);
    t2 = t1;
    memset(t2, (unsigned char)2, 16U);
    t3 = (t0 + 2808U);
    t4 = *((char **)t3);
    t3 = (t4 + 0);
    memcpy(t3, t1, 16U);

LAB92:    goto LAB2;

LAB23:    xsi_set_current_line(160, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 2808U);
    t3 = *((char **)t1);
    t1 = (t3 + 0);
    memcpy(t1, t2, 16U);
    goto LAB2;

LAB24:    xsi_set_current_line(161, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 2808U);
    t3 = *((char **)t1);
    t1 = (t3 + 0);
    memcpy(t1, t2, 16U);
    goto LAB2;

LAB48:;
LAB49:    xsi_set_current_line(71, ng0);
    t8 = (t0 + 4184);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t8);
    goto LAB50;

LAB52:    xsi_set_current_line(84, ng0);
    t8 = xsi_get_transient_memory(16U);
    memset(t8, 0, 16U);
    t9 = t8;
    memset(t9, (unsigned char)2, 16U);
    t11 = (t0 + 2808U);
    t12 = *((char **)t11);
    t11 = (t12 + 0);
    memcpy(t11, t8, 16U);
    xsi_set_current_line(85, ng0);
    t1 = (t0 + 4248);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB53;

LAB55:    t77 = 0;

LAB58:    if (t77 < 16U)
        goto LAB59;
    else
        goto LAB57;

LAB59:    t4 = (t2 + t77);
    t5 = (t1 + t77);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB56;

LAB60:    t77 = (t77 + 1);
    goto LAB58;

LAB61:    xsi_set_current_line(94, ng0);
    t8 = xsi_get_transient_memory(16U);
    memset(t8, 0, 16U);
    t9 = t8;
    memset(t9, (unsigned char)2, 16U);
    t11 = (t0 + 2808U);
    t12 = *((char **)t11);
    t11 = (t12 + 0);
    memcpy(t11, t8, 16U);
    xsi_set_current_line(95, ng0);
    t1 = (t0 + 4248);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB62;

LAB64:    t77 = 0;

LAB67:    if (t77 < 16U)
        goto LAB68;
    else
        goto LAB66;

LAB68:    t4 = (t2 + t77);
    t5 = (t1 + t77);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB65;

LAB69:    t77 = (t77 + 1);
    goto LAB67;

LAB70:    xsi_set_current_line(132, ng0);
    t5 = xsi_get_transient_memory(16U);
    memset(t5, 0, 16U);
    t8 = t5;
    memset(t8, (unsigned char)2, 16U);
    t9 = (t0 + 2808U);
    t11 = *((char **)t9);
    t9 = (t11 + 0);
    memcpy(t9, t5, 16U);
    xsi_set_current_line(133, ng0);
    t1 = (t0 + 2808U);
    t2 = *((char **)t1);
    t6 = (0 - 15);
    t77 = (t6 * -1);
    t78 = (1U * t77);
    t81 = (0 + t78);
    t1 = (t2 + t81);
    *((unsigned char *)t1) = (unsigned char)3;
    goto LAB71;

LAB73:    t77 = 0;

LAB76:    if (t77 < 16U)
        goto LAB77;
    else
        goto LAB75;

LAB77:    t1 = (t2 + t77);
    t4 = (t3 + t77);
    if (*((unsigned char *)t1) != *((unsigned char *)t4))
        goto LAB74;

LAB78:    t77 = (t77 + 1);
    goto LAB76;

LAB79:    xsi_set_current_line(139, ng0);
    t5 = xsi_get_transient_memory(16U);
    memset(t5, 0, 16U);
    t8 = t5;
    memset(t8, (unsigned char)2, 16U);
    t9 = (t0 + 2808U);
    t11 = *((char **)t9);
    t9 = (t11 + 0);
    memcpy(t9, t5, 16U);
    xsi_set_current_line(140, ng0);
    t1 = (t0 + 2808U);
    t2 = *((char **)t1);
    t6 = (0 - 15);
    t77 = (t6 * -1);
    t78 = (1U * t77);
    t81 = (0 + t78);
    t1 = (t2 + t81);
    *((unsigned char *)t1) = (unsigned char)3;
    goto LAB80;

LAB82:    t77 = 0;

LAB85:    if (t77 < 16U)
        goto LAB86;
    else
        goto LAB84;

LAB86:    t1 = (t2 + t77);
    t4 = (t3 + t77);
    if (*((unsigned char *)t1) != *((unsigned char *)t4))
        goto LAB83;

LAB87:    t77 = (t77 + 1);
    goto LAB85;

LAB88:    xsi_set_current_line(146, ng0);
    t5 = xsi_get_transient_memory(16U);
    memset(t5, 0, 16U);
    t8 = t5;
    memset(t8, (unsigned char)2, 16U);
    t9 = (t0 + 2808U);
    t11 = *((char **)t9);
    t9 = (t11 + 0);
    memcpy(t9, t5, 16U);
    xsi_set_current_line(147, ng0);
    t1 = (t0 + 2808U);
    t2 = *((char **)t1);
    t6 = (0 - 15);
    t77 = (t6 * -1);
    t78 = (1U * t77);
    t81 = (0 + t78);
    t1 = (t2 + t81);
    *((unsigned char *)t1) = (unsigned char)3;
    goto LAB89;

LAB91:    xsi_set_current_line(153, ng0);
    t5 = xsi_get_transient_memory(16U);
    memset(t5, 0, 16U);
    t8 = t5;
    memset(t8, (unsigned char)2, 16U);
    t9 = (t0 + 2808U);
    t11 = *((char **)t9);
    t9 = (t11 + 0);
    memcpy(t9, t5, 16U);
    xsi_set_current_line(154, ng0);
    t1 = (t0 + 2808U);
    t2 = *((char **)t1);
    t6 = (0 - 15);
    t77 = (t6 * -1);
    t78 = (1U * t77);
    t81 = (0 + t78);
    t1 = (t2 + t81);
    *((unsigned char *)t1) = (unsigned char)3;
    goto LAB92;

LAB94:    xsi_set_current_line(169, ng0);
    t8 = (t0 + 4376);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t8);
    goto LAB95;

LAB97:    t77 = 0;

LAB100:    if (t77 < 16U)
        goto LAB101;
    else
        goto LAB99;

LAB101:    t4 = (t2 + t77);
    t5 = (t1 + t77);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB98;

LAB102:    t77 = (t77 + 1);
    goto LAB100;

}


extern void work_a_3431638527_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3431638527_3212880686_p_0};
	xsi_register_didat("work_a_3431638527_3212880686", "isim/tb1_isim_beh.exe.sim/work/a_3431638527_3212880686.didat");
	xsi_register_executes(pe);
}
